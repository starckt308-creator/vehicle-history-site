/* Shared header, footer, icons and demo support chat. */
(function () {
  'use strict';
  var C = window.CV_CONFIG;
  if (!C) { console.error('CV_CONFIG missing. Load config.js before shared.js.'); return; }
  var page = document.body.getAttribute('data-page') || '';
  var ICONS = {
    shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
    chat:'<path d="M4 5h16v11H9l-5 4V5z"/>', x:'<path d="M6 6l12 12M18 6L6 18"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>'
  };
  window.CVIcon = function (name, size) {
    return '<svg class="icon" width="'+(size||24)+'" height="'+(size||24)+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(ICONS[name]||'')+'</svg>';
  };
  var links = [
    ['index.html','Home','home'],['how-it-works.html','How It Works','how'],
    ['sample-report.html','Sample Report','sample'],['pricing.html','Pricing','pricing'],
    ['faq.html','FAQ','faq'],['contact.html','Contact','contact']
  ];
  var parts = C.brand.name.split(' ');
  var wordmark = parts[0] + (parts.length > 1 ? '<b>'+parts.slice(1).join(' ')+'</b>' : '');
  var header = document.getElementById('site-header');
  if (header) {
    header.innerHTML =
      (C.demoMode ? '<div class="demo-bar">Demo mode · sample data only · no live vehicle lookups or payments</div>' : '')+
      '<div class="nav-wrap container"><a class="brand" href="index.html" aria-label="'+C.brand.name+' home"><span class="brand-mark">'+window.CVIcon('shield',23)+'</span><span class="wordmark">'+wordmark+'</span></a>'+
      '<nav id="primary-nav" class="nav" aria-label="Primary">'+links.map(function(l){return '<a href="'+l[0]+'"'+(l[2]===page?' aria-current="page"':'')+'>'+l[1]+'</a>';}).join('')+
      '<a class="nav-mobile-only" href="dashboard.html">My reports</a><a class="nav-mobile-only" href="login.html">Log in</a></nav>'+
      '<div class="nav-actions"><a class="btn btn-ghost btn-sm" href="dashboard.html">My reports</a><a class="btn btn-primary btn-sm" href="login.html">Log in</a>'+
      '<button class="nav-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Toggle menu"><span></span><span></span><span></span></button></div></div>';
    var toggle=header.querySelector('.nav-toggle');
    toggle.addEventListener('click',function(){var open=header.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
    header.querySelectorAll('.nav a').forEach(function(a){a.addEventListener('click',function(){header.classList.remove('open');toggle.setAttribute('aria-expanded','false');});});
  }
  var footer=document.getElementById('site-footer');
  if(footer){
    var flags=C.countries.slice(0,12).map(function(c){return '<span class="country-pill" title="'+c[1]+'">'+c[0].toUpperCase()+'</span>';}).join('');
    footer.innerHTML='<div class="container footer-grid"><div class="footer-brand"><a class="brand" href="index.html"><span class="brand-mark">'+window.CVIcon('shield',23)+'</span><span class="wordmark">'+wordmark+'</span></a><p>'+C.brand.tagline+' This starter site uses sample data until a data provider is connected.</p><div class="footer-flags" aria-label="Example country codes">'+flags+'</div></div>'+
      '<div><h3>Product</h3><a href="index.html">Home</a><a href="how-it-works.html">How It Works</a><a href="sample-report.html">Sample Report</a><a href="pricing.html">Pricing</a></div>'+
      '<div><h3>Support</h3><a href="faq.html">FAQ</a><a href="contact.html">Contact</a><a href="dashboard.html">My reports</a><a href="login.html">Account demo</a></div>'+
      '<div><h3>Legal</h3><a href="legal.html#privacy">Privacy</a><a href="legal.html#terms">Terms</a><a href="legal.html#returns">Report policy</a></div></div>'+
      '<div class="container footer-base"><span>© '+new Date().getFullYear()+' '+C.brand.name+'. Verify information with authoritative sources.</span><span>Demo build</span></div>';
  }
  document.title=document.title+' · '+C.brand.name;
  document.querySelectorAll('[data-brand]').forEach(function(el){el.textContent=C.brand.name;});
  var chat=document.createElement('div');
  chat.innerHTML='<button id="chat-fab" class="chat-fab" type="button" aria-expanded="false" aria-controls="chat-panel">'+window.CVIcon('chat',25)+'<span class="sr-only">Open support chat</span></button>'+
    '<section id="chat-panel" class="chat-panel" role="dialog" aria-label="Support chat" hidden><header><div><strong>Support assistant</strong> <span class="chip">Demo</span></div><button id="chat-close" class="chat-close" type="button" aria-label="Close chat">'+window.CVIcon('x',18)+'</button></header>'+
    '<div id="chat-log" class="chat-log" role="log" aria-live="polite"><div class="chat-bubble bot">Hi! I’m the demo assistant. Ask about sample reports, pricing, or how this website works.</div></div>'+
    '<form id="chat-form" autocomplete="off"><label class="sr-only" for="chat-input">Your message</label><input id="chat-input" maxlength="500" placeholder="Ask a question…" required><button class="btn btn-primary btn-sm" type="submit">Send</button></form><p class="chat-note">Demo replies only. Don’t share passwords or payment details.</p></section>';
  document.body.appendChild(chat);
  var fab=document.getElementById('chat-fab'), panel=document.getElementById('chat-panel'), close=document.getElementById('chat-close');
  function setChat(open){panel.hidden=!open;fab.setAttribute('aria-expanded',String(open));if(open)document.getElementById('chat-input').focus();}
  fab.addEventListener('click',function(){setChat(panel.hidden);});close.addEventListener('click',function(){setChat(false);});
  document.getElementById('chat-form').addEventListener('submit',function(e){
    e.preventDefault();var input=document.getElementById('chat-input'), message=input.value.trim();if(!message)return;
    addBubble(message,'user');input.value='';
    var lower=message.toLowerCase(), reply='This is a demo support chat. No live vehicle database or AI service is connected yet.';
    if(/price|pricing|cost|payment/.test(lower)) reply='The pricing page is a placeholder for now. No payments are taken in this demo.';
    else if(/vin|vehicle|report|history/.test(lower)) reply='You can try the VIN form on the homepage or open the sample report. Both use demo data only.';
    else if(/hello|hi\b|hey/.test(lower)) reply='Hello! I can point you to the sample report, explain the demo lookup, or help you plan the next build step.';
    window.setTimeout(function(){addBubble(reply,'bot');},250);
  });
  function addBubble(text,who){var b=document.createElement('div');b.className='chat-bubble '+who;b.textContent=text;document.getElementById('chat-log').appendChild(b);document.getElementById('chat-log').scrollTop=999999;}
})();