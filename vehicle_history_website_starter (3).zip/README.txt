CLEARVIN VEHICLE HISTORY WEBSITE — STARTER BUILD

WHAT'S INCLUDED
- Responsive homepage and shared navigation/footer
- VIN-style demo lookup that opens a clearly labelled sample report
- How It Works, Sample Report, Pricing, FAQ, Contact, My Reports, Account Demo and Legal pages
- Floating support chat with local demo responses
- No paid services or API keys required to preview locally

RUN IT
1. Extract this ZIP into a folder.
2. Open index.html in a modern browser.
3. If your browser restricts local files, use a free local server such as VS Code's Live Server extension, or run:
   python -m http.server 8000
   Then visit http://localhost:8000

CUSTOMIZE
- Change the brand name/tagline in config.js.
- Adjust colors and layout in styles.css.
- shared.js builds the common header/footer and demo chat.
- app.js handles the demo lookup and sample VIN display.

IMPORTANT LIMITATIONS
This is a front-end starter, not a live vehicle-history service. It does not connect to vehicle registries, VIN decoders, accident/auction databases, accounts, persistent storage, email, payments, or a real AI API. Never put secret API keys in browser JavaScript. Live lookups and real AI chat should be implemented through a backend with provider credentials stored securely. Review privacy, terms, data-provider licensing, and country coverage before public launch.
